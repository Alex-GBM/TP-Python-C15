from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional


class ParkingSystem:
    def __init__(
        self,
        capacity: int,
        hourly_rate: float,
        storage_path: Optional[str | Path] = None,
        rates_by_vehicle_type: Optional[Dict[str, float]] = None,
    ) -> None:
        self.capacity = min(int(capacity), 40)
        self.hourly_rate = hourly_rate
        self.storage_path = Path(storage_path) if storage_path is not None else None
        self.rates_by_vehicle_type = {
            key.lower(): float(value) for key, value in (rates_by_vehicle_type or {}).items()
        }
        self.occupied_spaces = 0
        self.vehicles: Dict[str, Dict[str, Any]] = {}
        self.available_spots: list[int] = []
        self.history: list[dict] = []
        self.total_stay_minutes = 0
        self.vehicles_attended = 0
        self.vehicle_type_counts: Dict[str, int] = {}
        self._refresh_available_spots()
        if self.storage_path is not None:
            self.load_state()

    @property
    def available_spaces(self) -> int:
        return self.capacity - self.occupied_spaces

    def _refresh_available_spots(self) -> None:
        occupied_spots = {int(vehicle.get("spot", 0)) for vehicle in self.vehicles.values() if vehicle.get("spot")}
        self.available_spots = [spot for spot in range(1, self.capacity + 1) if spot not in occupied_spots]

    def enter_vehicle(self, plate: str, vehicle_type: str, entry_time: datetime) -> bool:
        if self.available_spaces <= 0:
            return False
        if plate in self.vehicles:
            return False

        normalized_type = vehicle_type.strip().lower() or "auto"
        spot = self.available_spots.pop(0)
        self.vehicles[plate] = {
            "type": normalized_type,
            "entry_time": entry_time,
            "spot": spot,
        }
        self.occupied_spaces += 1
        self.save_state()
        return True

    def exit_vehicle(self, plate: str, exit_time: datetime) -> Optional[Dict[str, Any]]:
        vehicle = self.vehicles.pop(plate, None)
        if vehicle is None:
            return None

        entry_time = vehicle["entry_time"]
        stay_minutes = max(int((exit_time - entry_time).total_seconds() // 60), 0)
        amount_paid = self._calculate_amount(stay_minutes, vehicle["type"])

        self.occupied_spaces -= 1
        self.available_spots.append(vehicle["spot"])
        self.available_spots.sort()
        self.total_stay_minutes += stay_minutes
        self.vehicles_attended += 1
        self.vehicle_type_counts[vehicle["type"]] = self.vehicle_type_counts.get(vehicle["type"], 0) + 1

        record = {
            "plate": plate,
            "vehicle_type": vehicle["type"],
            "entry_time": entry_time,
            "exit_time": exit_time,
            "stay_minutes": stay_minutes,
            "amount_paid": amount_paid,
        }
        self.history.append(record)
        self.save_state()
        return record

    def _calculate_amount(self, stay_minutes: int, vehicle_type: str) -> int:
        rate = self.rates_by_vehicle_type.get(vehicle_type.lower())
        if rate is None:
            rate = self.hourly_rate
        hours = max(1, (stay_minutes + 59) // 60)
        return int(hours * rate)

    def get_statistics(self) -> Dict[str, Any]:
        average_stay_minutes = (
            self.total_stay_minutes / self.vehicles_attended if self.vehicles_attended else 0.0
        )
        occupancy_rate = self.occupied_spaces / self.capacity if self.capacity else 0.0
        return {
            "vehicles_attended": self.vehicles_attended,
            "occupancy_rate": occupancy_rate,
            "average_stay_minutes": average_stay_minutes,
            "vehicle_type_counts": dict(self.vehicle_type_counts),
            "current_occupied_spaces": self.occupied_spaces,
        }

    def get_parking_map(self) -> list[str]:
        map_lines: list[str] = []
        for row in range(0, self.capacity, 10):
            line = []
            for spot in range(row + 1, min(row + 11, self.capacity + 1)):
                if any(vehicle.get("spot") == spot for vehicle in self.vehicles.values()):
                    line.append("[X]")
                else:
                    line.append(f"[{spot:02d}]")
            map_lines.append(" ".join(line))
        return map_lines

    def clear_vehicles(self) -> None:
        self.vehicles = {}
        self.occupied_spaces = 0
        self.available_spots = list(range(1, self.capacity + 1))
        self.history = []
        self.total_stay_minutes = 0
        self.vehicles_attended = 0
        self.vehicle_type_counts = {}
        self.save_state()

    def save_state(self) -> None:
        if self.storage_path is None:
            return

        self.storage_path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "capacity": self.capacity,
            "hourly_rate": self.hourly_rate,
            "rates_by_vehicle_type": self.rates_by_vehicle_type,
            "occupied_spaces": self.occupied_spaces,
            "vehicles": {
                plate: {
                    "type": data["type"],
                    "entry_time": data["entry_time"].isoformat(),
                    "spot": data["spot"],
                }
                for plate, data in self.vehicles.items()
            },
            "history": [
                {
                    **record,
                    "entry_time": record["entry_time"].isoformat(),
                    "exit_time": record["exit_time"].isoformat(),
                }
                for record in self.history
            ],
            "total_stay_minutes": self.total_stay_minutes,
            "vehicles_attended": self.vehicles_attended,
            "vehicle_type_counts": self.vehicle_type_counts,
        }
        with self.storage_path.open("w", encoding="utf-8") as handle:
            json.dump(payload, handle, indent=2, ensure_ascii=False)

    def load_state(self) -> bool:
        if self.storage_path is None or not self.storage_path.exists():
            return False

        try:
            with self.storage_path.open("r", encoding="utf-8") as handle:
                data = json.load(handle)
        except (json.JSONDecodeError, OSError):
            return False

        self.capacity = int(data.get("capacity", self.capacity))
        self.hourly_rate = float(data.get("hourly_rate", self.hourly_rate))
        self.rates_by_vehicle_type = {
            str(key).lower(): float(value)
            for key, value in data.get("rates_by_vehicle_type", {}).items()
        }
        self.occupied_spaces = int(data.get("occupied_spaces", 0))
        self.vehicles = {
            plate: {
                "type": item.get("type", "auto"),
                "entry_time": datetime.fromisoformat(item["entry_time"]),
                "spot": int(item.get("spot", 0)),
            }
            for plate, item in data.get("vehicles", {}).items()
        }
        self.history = [
            {
                **record,
                "entry_time": datetime.fromisoformat(record["entry_time"]),
                "exit_time": datetime.fromisoformat(record["exit_time"]),
            }
            for record in data.get("history", [])
        ]
        self.total_stay_minutes = int(data.get("total_stay_minutes", 0))
        self.vehicles_attended = int(data.get("vehicles_attended", 0))
        self.vehicle_type_counts = {
            str(key): int(value) for key, value in data.get("vehicle_type_counts", {}).items()
        }
        self._refresh_available_spots()
        return True


if __name__ == "__main__":
    from datetime import datetime, timedelta

    # Inicializamos el sistema con capacidad de 40 lugares
    parking = ParkingSystem(capacity=40, hourly_rate=1500, storage_path="estacionamiento.json")
    
    while True:
        print("\n" + "="*35)
        print("   SISTEMA DE ESTACIONAMIENTO (40)")
        print("="*35)
        print(f" Lugares libres: {parking.available_spaces} / {parking.capacity}")
        print("-"*35)
        print("1. Ingresar vehículo")
        print("2. Registrar salida de vehículo (Manual)")
        print("3. Ver mapa del estacionamiento")
        print("4. Ver estadísticas de hoy")
        print("5. Salir")
        print("="*35)
        
        opcion = input("Seleccione una opción (1-5): ").strip()
        
        if opcion == "1":
            patente = input("Ingrese la patente: ").strip().upper()
            
            # Menú de selección de tipo de vehículo para estandarizar el texto
            print("\n--- Tipo de Vehículo ---")
            print("1. Auto")
            print("2. Moto")
            print("3. PickUp")
            tipo_opcion = input("Seleccione el tipo (1-3): ").strip()
            
            # Mapeamos el número ingresado a la palabra correspondiente
            if tipo_opcion == "1":
                tipo = "Auto"
            elif tipo_opcion == "2":
                tipo = "Moto"
            elif tipo_opcion == "3":
                tipo = "PickUp"
            else:
                print("⚠️ Opción inválida. Se registrará como 'Auto' por defecto.")
                tipo = "Auto"
            
            print("\n¿Tipo de estadía?")
            print("1. Tiempo indefinido (Registra hora de entrada actual)")
            print("2. Tiempo definido (Establece cantidad de horas)")
            tipo_estadia = input("Seleccione (1 o 2): ").strip()
            
            hora_ingreso = datetime.now()
            
            if tipo_estadia == "2":
                try:
                    horas = int(input("¿Cuántas horas se va a quedar?: ").strip())
                    if horas <= 0:
                        print("⚠️ Cantidad de horas inválida. Se asignará tiempo indefinido.")
                    else:
                        # Simulamos el ingreso restando las horas para el cálculo interno
                        hora_ingreso = datetime.now() - timedelta(hours=horas)
                        print(f"⏱️ Modo definido: Se configuraron {horas} horas de estadía.")
                except ValueError:
                    print("⚠️ Entrada inválida. Se asignará tiempo indefinido.")

            exito = parking.enter_vehicle(patente, tipo, hora_ingreso)
            if exito:
                # Mostramos la hora exacta en la que el sistema registró el ingreso
                print(f"✅ Vehículo {patente} ingresado a las {hora_ingreso.strftime('%H:%M:%S')}.")
            else:
                print("❌ No se pudo ingresar (Estacionamiento lleno o patente ya registrada).")
                
        elif opcion == "2":
            patente = input("Ingrese la patente del vehículo que sale: ").strip().upper()
            
            # Verificamos primero si el auto realmente existe en el sistema
            if patente not in parking.vehicles:
                print("❌ La patente ingresada no se encuentra en el sistema.")
            else:
                print(f"Vehículo encontrado. Ingresó a las: {parking.vehicles[patente]['entry_time'].strftime('%H:%M:%S')}")
                print("\n--- Registrar Hora de Salida ---")
                try:
                    hora_salida_input = int(input("Ingrese la HORA de salida (0-23): ").strip())
                    minutos_salida_input = int(input("Ingrese los MINUTOS de salida (0-59): ").strip())
                    
                    # Tomamos la fecha de hoy pero le sobreescribimos la hora y minutos que ingresaste
                    ahora = datetime.now()
                    hora_salida = ahora.replace(hour=hora_salida_input, minute=minutos_salida_input, second=0, microsecond=0)
                    
                    # Si la hora de salida ingresada es menor a la de entrada, asumimos que es del día siguiente
                    if hora_salida < parking.vehicles[patente]['entry_time']:
                        hora_salida += timedelta(days=1)

                    # Procesamos la salida con tu hora manual
                    ticket = parking.exit_vehicle(patente, hora_salida)
                    
                    if ticket:
                        print("\n" + "-"*30)
                        print("       TICKET DE SALIDA")
                        print("-"*30)
                        print(f"Patente:     {ticket['plate']}")
                        print(f"Tipo:        {ticket['vehicle_type'].upper()}")
                        print(f"Entrada:     {ticket['entry_time'].strftime('%H:%M')}")
                        print(f"Salida:      {ticket['exit_time'].strftime('%H:%M')}")
                        print(f"Estadía:     {ticket['stay_minutes']} minutos")
                        print(f"Total cobrado: ${ticket['amount_paid']}")
                        print("-"*30)
                except ValueError:
                    print("❌ Error: Debes ingresar números válidos para la hora y los minutos.")
                
        elif opcion == "3":
            print("\n--- MAPA DE OCUPACIÓN ---")
            mapa = parking.get_parking_map()
            for fila in mapa:
                print(fila)
                
        elif opcion == "4":
            stats = parking.get_statistics()
            print("\n--- ESTADÍSTICAS DEL DÍA ---")
            print(f"Vehículos atendidos:      {stats['vehicles_attended']}")
            print(f"Tasa de ocupación actual: {stats['occupancy_rate'] * 100:.1f}%")
            print(f"Tiempo promedio de estadía: {stats['average_stay_minutes']:.1f} min")
            print("Cantidad por tipo:")
            for t, cant in stats['vehicle_type_counts'].items():
                print(f"  - {t.upper()}: {cant}")
                
        elif opcion == "5":
            print("💾 Estado guardado. Saliendo del sistema... ¡Hasta luego!")
            break
        else:
            print("⚠️ Opción inválida. Intente de nuevo.")
